import numpy as np, scipy.sparse.linalg as spla, json, time
from scipy.sparse.linalg import LinearOperator
from graphatlas import nnls_rung, flags
from hypercube import level_masses_port, synth_moments, truths
t0=time.time(); K=24; G_CUT=5e-3; res={}
def mk(l,r,eb):
    Bt=l-r; n=1<<l; w=np.array([1.0]*Bt+[eb]*r); ws=float(w.sum())
    idxs=[np.arange(n)^(1<<i) for i in range(l)]
    def Lmv(x):
        y=ws*x
        for i in range(l): y=y-w[i]*x[idxs[i]]
        return y
    return Lmv,2*ws,Bt,n
def cg(Lmv,s,b,n,tol=1e-12):
    A=LinearOperator((n,n),matvec=lambda x:Lmv(x)+s*x)
    x,info=spla.cg(A,b,rtol=tol,maxiter=200000); assert info==0
    return x
def moments_matrix(Lmv,s,B,n,K):
    # y-warp Chebyshev via CG solves: Y b = 2s(L+s)^-1 b - b
    C=B.shape[1]; mu=np.zeros((K,C)); nb2=np.sum(B*B,0)
    Tm1=B.copy()
    Y=np.stack([2*s*cg(Lmv,s,B[:,c],n)-B[:,c] for c in range(C)],1)
    T=Y
    mu[0]=nb2; mu[1]=np.sum(B*T,0)
    for k in range(2,K):
        Tn=np.stack([2*(2*s*cg(Lmv,s,T[:,c],n)-T[:,c]) for c in range(C)],1)-Tm1
        mu[k]=np.sum(B*Tn,0); Tm1,T=T,Tn
    return mu,nb2
for l in (10,14):
    r,eb=3,1e-3
    Lmv,alpha,Bt,n=mk(l,r,eb)
    ports={"d1":(1,0),"mid":(Bt//2,r//2),"anti":(Bt,r),"canary":(0,r)}
    masks={"d1":1,"mid":sum(1<<i for i in range(Bt//2))|(1<<Bt),"anti":(1<<l)-1,
           "canary":sum(1<<(Bt+i) for i in range(r))}
    names=list(ports); B=np.zeros((n,4))
    for p,nm in enumerate(names): B[0,p]=1.0; B[masks[nm],p]=-1.0
    one=np.ones(n)/np.sqrt(n); B=B-np.outer(one,one@B)  # deflate
    sig=[1e-3,1e-2,1e-1,1,10,100]
    grid=np.logspace(-4,np.log10(1.2*alpha),400)
    mus={};models={};dmax=0.0
    for s in sig:
        mu_raw,nb2=moments_matrix(Lmv,s,B,n,K)
        mu=mu_raw/nb2[None,:]          # normalized convention (mu0=1), matches moments_block
        mus[s]=mu
        models[s]=nnls_rung(mu,nb2,grid,s,K)
        for p,nm in enumerate(names):
            lamL,mL=level_masses_port(l,r,eb,*ports[nm])
            dmax=max(dmax,float(np.max(np.abs(synth_moments(lamL,mL,s,K)-mu[:,p]))))
        print("l=%d rung %g done %.0fs"%(l,s,time.time()-t0),flush=True)
    res[f"l{l}_PH1_maxdiff"]=dmax
    if l==10:
        # lntau truth gate: dense slogdet (n=1024)
        import scipy.sparse as sp
        w=np.array([1.0]*Bt+[eb]*r)
        rows=[];cols=[];vals=[]
        for i in range(l):
            ii=np.arange(n); rows.append(ii); cols.append(ii^(1<<i)); vals.append(np.full(n,-w[i]))
        Ld=(sp.coo_matrix((np.concatenate(vals),(np.concatenate(rows),np.concatenate(cols))),shape=(n,n)).toarray()
            +np.diag(np.full(n,w.sum())))
        sgn,ld=np.linalg.slogdet(Ld[1:,1:])
        tt=truths(l,r,eb,ports)
        res["l10_lntau_gate"]=abs(ld/n-tt["dos"]["lntau_per_node"])  # det(L_r)=tau (matrix-tree), no extra ln n
        print("l10 gate %.2e"%res["l10_lntau_gate"],flush=True)
        continue
    gm=np.array([flags(mus[s])[0] for s in sig]); fm=np.array([flags(mus[s])[1] for s in sig])
    alive=[[sig[d] for d in range(len(sig)) if gm[d,p]>=G_CUT] or [sig[-1]] for p in range(4)]
    res["l14_alive"]={names[p]:alive[p] for p in range(4)}
    sv=np.logspace(-3,np.log10(alpha),25)
    Rs_t=np.array([[float(B[:,p]@cg(Lmv,s,B[:,p],n)) for s in sv] for p in range(4)])
    Reff_t=np.array([float(B[:,p]@cg(Lmv,1e-8,B[:,p],n)) for p in range(4)])
    print("l=14 truths %.0fs"%(time.time()-t0),flush=True)
    def ev(p,s,force=None):
        sg=np.array(sorted(force if force else alive[p]))
        d=sg[0] if s<=0 else sg[int(np.argmin(np.abs(np.log10(sg)-np.log10(s))))]
        return float(models[d][p]@(1.0/(grid+s)))
    band=np.array([[abs(ev(p,s)-Rs_t[p,i])/Rs_t[p,i] for i,s in enumerate(sv)] for p in range(4)])
    reff=np.array([abs(ev(p,0)-Reff_t[p])/Reff_t[p] for p in range(4)])
    cf=abs(ev(3,0,force=sig)-Reff_t[3])/Reff_t[3]
    lamC,mC=level_masses_port(l,r,eb,0,r); sm=lamC<0.1
    res["l14_band_med_noncanary_pct"]=100*float(np.median(band[:3]))
    res["l14_reff_noncanary_pct"]=[100*float(x) for x in reff[:3]]
    res["l14_canary"]=dict(err_full_pct=100*float(cf),err_pruned_pct=100*float(reff[3]),
        ratio=float(reff[3]/cf) if cf>0 else float('inf'),
        smallmode_Reff_frac=float(2*np.sum(mC[sm&(lamC>0)]/lamC[sm&(lamC>0)])/Reff_t[3]))
    rng=np.random.default_rng(434343); T=100; eps=3e-4; nb2=np.sum(B*B,0)
    tm=np.empty((T,4))
    for t in range(T):
        for p in range(4):
            s0=sorted(alive[p])[0]; ri=sig.index(s0)
            ee=eps/10 if fm[ri,p]<0.51 else eps
            mu_n=mus[s0][:,p].copy(); mu_n[1:]+=ee*rng.standard_normal(K-1)  # normalized-moment noise
            wfit=nnls_rung(mu_n[:,None],np.array([nb2[p]]),grid,s0,K)
            tm[t,p]=abs(float(wfit[0]@(1.0/grid))-Reff_t[p])/Reff_t[p]
    pm=np.median(tm,0)
    res["l14_noise_trialmed_noncanary_med_pct"]=100*float(np.median(pm[:3]))
    res["l14_noise_trialmed_all_pct"]=[100*float(x) for x in pm]
    tt=truths(l,r,eb,ports)
    res["l14_Reff_analytic_vs_numeric_max"]=float(np.max(np.abs(np.array([tt[nm]["Reff"] for nm in names])-Reff_t)/Reff_t))
json.dump(res,open("res_armA.json","w"),indent=1)
print("ARM A DONE %.0fs"%(time.time()-t0))
