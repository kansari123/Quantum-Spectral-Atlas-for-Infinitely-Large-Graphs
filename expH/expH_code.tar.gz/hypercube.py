"""Two-scale hypercube Q_l: exact level measures (big-int), synthesized
rung moments, analytic truths. Levels (a,b): lam=2a+2*eb*b."""
import numpy as np
from math import comb, lgamma, log
from fractions import Fraction

def level_masses_port(l, r, eb, db, dw):
    Bt=l-r
    # bulk odd-overlap counts O_a via (1-x)^db (1+x)^(Bt-db)
    def odd_counts(m_d, m_tot):
        p=np.zeros(m_d+1,dtype=object)
        for j in range(m_d+1): p[j]=comb(m_d,j)*((-1)**j)
        q=np.zeros(m_tot-m_d+1,dtype=object)
        for j in range(m_tot-m_d+1): q[j]=comb(m_tot-m_d,j)
        c=np.convolve(p,q)          # coeffs of (1-x)^d (1+x)^(T-d)
        O=[(comb(m_tot,a)-int(c[a]))//2 for a in range(m_tot+1)]
        E=[comb(m_tot,a)-O[a] for a in range(m_tot+1)]
        return O,E
    Ob,Eb=odd_counts(db,Bt); Ow,Ew=odd_counts(dw,r)
    lam=np.zeros((Bt+1)*(r+1)); mass=np.zeros((Bt+1)*(r+1)); k=0
    den=1<<(l-1)   # mass = C_par / 2^(l-1)
    for a in range(Bt+1):
        for b in range(r+1):
            cp=Ob[a]*Ew[b]+Eb[a]*Ow[b]
            lam[k]=2.0*a+2.0*eb*b
            mass[k]=float(Fraction(cp,den)); k+=1
    s=mass.sum()
    assert abs(s-1)<1e-12, s
    return lam, mass

def level_masses_dos(l, r, eb):
    Bt=l-r; den=1<<l
    lam=[];mass=[]
    for a in range(Bt+1):
        ca=comb(Bt,a)
        for b in range(r+1):
            if a==0 and b==0: continue
            lam.append(2.0*a+2.0*eb*b)
            mass.append(float(Fraction(ca*comb(r,b),den)))
    lam=np.array(lam);mass=np.array(mass)
    return lam,mass/mass.sum()   # deflated & renormalized (drop ~2^-l)

def synth_moments(lam, mass, sigma, K):
    y=2.0*sigma/(sigma+lam)-1.0
    mu=np.zeros(K); Tm1=np.ones_like(y); T=y.copy()
    mu[0]=mass.sum(); mu[1]=float(mass@T)
    for k in range(2,K):
        Tn=2.0*y*T-Tm1; mu[k]=float(mass@Tn); Tm1,T=T,Tn
    return mu

def truths(l, r, eb, ports):
    out={}
    for name,(db,dw) in ports.items():
        lam,m=level_masses_port(l,r,eb,db,dw)
        nz=lam>0
        out[name]=dict(Reff=2.0*float((m[nz]/lam[nz]).sum()))
    lamD,mD=level_masses_dos(l,r,eb)
    fac=1.0-2.0**(-l)   # nonzero-level fraction (deflated zero mode)
    out["dos"]=dict(trLp_per_node=fac*float((mD/lamD).sum()),
                    lntau_per_node=fac*float((mD*np.log(lamD)).sum())-l*log(2.0)*np.exp(-l*log(2.0)))
    return out
