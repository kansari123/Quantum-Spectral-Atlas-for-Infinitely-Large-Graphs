import numpy as np, json, time
from math import comb
from scipy.optimize import nnls, lsq_linear
from graphatlas import nnls_rung, flags
from hypercube import level_masses_port, level_masses_dos, synth_moments, truths
t0=time.time(); K=24; G_CUT=5e-3; eps=3e-4; T=100
def run_l(l, r=6, eb=1e-3, do_noise=True, ports_sel=None):
    Bt=l-r; alpha=2.0*(Bt*1.0+r*eb)
    ports={"d1":(1,0),"mid":(Bt//2,r//2),"anti":(Bt,r),"canary":(0,r)}
    if ports_sel: ports={k:ports[k] for k in ports_sel}
    names=list(ports)
    meas=[]  # (lam, mass, nb2) per column; DOS last
    for nm in names:
        lam,m=level_masses_port(l,r,eb,*ports[nm]); meas.append((lam,m,2.0))
        print("  mass %s %.0fs"%(nm,time.time()-t0),flush=True)
    lamD,mD=level_masses_dos(l,r,eb); meas.append((lamD,mD,1.0))
    C=len(meas)
    sig=[1e-3,1e-2,1e-1,1,10,100,1000]
    grid=np.logspace(-4,np.log10(1.2*alpha),400)
    MU=np.zeros((len(sig),K,C)); NB2=np.array([m[2] for m in meas])
    for d,s in enumerate(sig):
        for c,(lam,m,nb2) in enumerate(meas):
            MU[d,:,c]=synth_moments(lam,m,s,K)  # normalized (mu0=1)
    models=[nnls_rung(MU[d],NB2,grid,sig[d],K) for d in range(len(sig))]
    gm=np.array([flags(MU[d])[0] for d in range(len(sig))])
    fm=np.array([flags(MU[d])[1] for d in range(len(sig))])
    alive=[[sig[d] for d in range(len(sig)) if gm[d,c]>=G_CUT] or [sig[-1]] for c in range(C)]
    tt=truths(l,r,eb,{nm:ports[nm] for nm in names})
    inv_g=1.0/grid; log_g=np.log(grid)
    def ev(c,s):
        sg=np.array(sorted(alive[c]))
        d=sg[0] if s<=0 else sg[int(np.argmin(np.abs(np.log10(sg)-np.log10(s))))]
        return float(models[sig.index(d)][c]@(1.0/(grid+s)))
    out=dict(l=l,n_log10=l*np.log10(2),alive={(names+["dos"])[c]:alive[c] for c in range(C)},
             fmat=[[float(fm[d,c]) for c in range(C)] for d in range(len(sig))])
    # R_eff + 5-point sweep vs analytic
    svals=np.logspace(0,2,5); rr={}
    for c,nm in enumerate(names):
        lam,m,_=meas[c]
        Rt0=tt[nm]["Reff"]; rr[nm]=dict(
          Reff_true=Rt0, Reff_err_pct=100*abs(ev(c,0)-Rt0)/Rt0,
          band_err_pct=[100*abs(ev(c,s)-2*float((m/(lam+s)).sum()))/(2*float((m/(lam+s)).sum())) for s in svals])
    out["ports"]=rr
    # functionals: joint (primary) + stitched (diagnostic), DOS column
    cD=C-1; lamD,mD,_=meas[cD]
    def joint(mu_col):  # mu_col (len(sig),K) raw
        rows=[100.0*np.ones(len(grid))]; rhs=[100.0]
        for d,s in enumerate(sig):
            if s not in alive[cD]: continue
            y=2.0*s/(s+grid)-1.0; th=np.arccos(np.clip(y,-1,1))
            rows.append(np.cos(np.outer(np.arange(1,K),th))); rhs.append(mu_col[d,1:])
        A=np.vstack([q if q.ndim==2 else q[None,:] for q in rows]); b=np.concatenate([np.atleast_1d(q) for q in rhs])
        try: w,_=nnls(A,b,maxiter=200*A.shape[1])
        except RuntimeError: w=lsq_linear(A,b,bounds=(0,np.inf),method='trf',tol=1e-12,max_iter=400).x
        return NB2[cD]*w
    Wj=joint(MU[:,:,cD])
    def stitch(c):
        sg=np.sort(np.array(sorted(alive[c]),dtype=float))
        assign=np.argmin(np.abs(np.log10(grid)[:,None]-np.log10(sg)[None,:]),axis=1)
        Wst=np.zeros(len(grid))
        for di,s in enumerate(sg): Wst[assign==di]=models[sig.index(s)][c][assign==di]
        return Wst
    Ws=stitch(cD)
    tr_t=tt["dos"]["trLp_per_node"]; lt_t=tt["dos"]["lntau_per_node"]
    out["functionals"]=dict(
      trLp_true=tr_t, lntau_true=lt_t,
      trLp_joint_err_pct=100*abs(float(Wj@inv_g)-tr_t)/tr_t,
      lntau_joint_err_nats=abs(float(Wj@log_g)-l*np.log(2.0)*np.exp(-l*np.log(2.0))-lt_t),
      trLp_stitch_err_pct=100*abs(float(Ws@inv_g)-tr_t)/tr_t,
      lntau_stitch_err_nats=abs(float(Ws@log_g)-l*np.log(2.0)*np.exp(-l*np.log(2.0))-lt_t))
    # depth ledger
    D={s:int(np.ceil(4*np.sqrt(alpha/s))) for s in sig}
    out["depth"]=dict(D=D,SumD_naive=int(sum(D.values())),
      SumD_pruned={(names+["dos"])[c]:int(sum(D[s] for s in alive[c])) for c in range(C)},
      ratio_naive_over_pruned_dos=sum(D.values())/max(1,sum(D[s] for s in alive[cD])))
    if do_noise:
        rng=np.random.default_rng(434343)
        pe=np.empty((T,len(names))); te=np.empty(T); le=np.empty(T)
        for t in range(T):
            for c,nm in enumerate(names):
                s0=sorted(alive[c])[0]; d0=sig.index(s0)
                ee=eps/10 if fm[d0,c]<0.51 else eps
                mu_n=MU[d0,:,c].copy(); mu_n[1:]+=ee*rng.standard_normal(K-1)
                wfit=nnls_rung(mu_n[:,None],np.array([NB2[c]]),grid,s0,K)
                pe[t,c]=abs(float(wfit[0]@inv_g)-tt[nm]["Reff"])/tt[nm]["Reff"]
            mu_nD=MU[:,:,cD].copy()
            for d,s in enumerate(sig):
                ee=eps/10 if fm[d,cD]<0.51 else eps
                mu_nD[d,1:]+=ee*rng.standard_normal(K-1)
            Wjn=joint(mu_nD)
            te[t]=abs(float(Wjn@inv_g)-tr_t)/tr_t
            le[t]=abs(float(Wjn@log_g)-l*np.log(2.0)*np.exp(-l*np.log(2.0))-lt_t)
        out["noise"]=dict(Reff_trialmed_pct={nm:100*float(np.median(pe[:,c])) for c,nm in enumerate(names)},
          trLp_med_pct=100*float(np.median(te)), lntau_med_nats=float(np.median(le)))
    print(json.dumps(out["functionals"],indent=1),flush=True)
    return out
R={}
for l in (266,1000):
    print("=== l=%d ==="%l,flush=True)
    R[str(l)]=run_l(l)
    json.dump(R,open("res_armB.json","w"),indent=1)
print("=== l=2000 (X-H1, anti+dos only, noiseless) ===",flush=True)
R["2000"]=run_l(2000,do_noise=False,ports_sel=["anti"])
json.dump(R,open("res_armB.json","w"),indent=1)
print("ARM B DONE %.0fs"%(time.time()-t0))
