"""Exact-class per-probe quadratic forms <z|f(L)|z> via fully
reorthogonalized Lanczos on the deflated Laplacian. Self-consistency
gate k=300 vs k=500 and cross-check vs solve-based q_inv_true."""
import numpy as np, scipy.sparse as sp, scipy.linalg as sla, time
t0=time.time()
W=sp.load_npz("lastfm_W.npz"); n=W.shape[0]
deg=np.asarray(W.sum(1)).ravel(); L=(sp.diags(deg)-W).tocsr()
one=np.ones(n)/np.sqrt(n)
d=np.load("stage2a.npz"); Z=d["Z"]; M=Z.shape[1]

def lanczos_quad(z, k):
    q=z-(one@z)*one; nb2=float(q@q); q=q/np.sqrt(nb2)
    Q=np.empty((n,k)); Q[:,0]=q
    a=np.empty(k); b=np.empty(k-1)
    for j in range(k):
        w=L@Q[:,j]
        w-= (one@w)*one
        a[j]=float(Q[:,j]@w)
        w-=a[j]*Q[:,j]
        if j>0: w-=b[j-1]*Q[:,j-1]
        # full reorth (twice)
        for _ in range(2):
            w-=Q[:,:j+1]@(Q[:,:j+1].T@w)
        if j<k-1:
            b[j]=np.linalg.norm(w)
            if b[j]<1e-14: 
                k=j+1; a=a[:k]; b=b[:k-1]; Q=Q[:,:k]; break
            Q[:,j+1]=w/b[j]
    th,S=sla.eigh_tridiagonal(a,b)
    w0=nb2*S[0,:]**2
    return th,w0,nb2

res={}
for k in (300,500):
    qi=[];ql=[]
    for z in Z.T:
        th,w0,nb2=lanczos_quad(z,k)
        qi.append(float(np.sum(w0/th))); ql.append(float(np.sum(w0*np.log(th))))
    res[k]=(np.array(qi),np.array(ql))
    print("k=%d done %.1fs"%(k,time.time()-t0),flush=True)
qi3,ql3=res[300]; qi5,ql5=res[500]
sc_inv=np.max(np.abs(qi5-qi3)/np.abs(qi5)); sc_log=np.max(np.abs(ql5-ql3)/np.abs(ql5))
ts=np.load("stage2truth_solves.npz")
xchk=np.max(np.abs(qi5-ts["q_inv_true"])/ts["q_inv_true"])
print("self-consistency inv=%.2e log=%.2e ; cross-vs-solves inv=%.2e"%(sc_inv,sc_log,xchk))
np.savez("lanczos_truth.npz",q_inv_true=qi5,q_log_true=ql5,
         self_inv=sc_inv,self_log=sc_log,cross_inv=xchk)
