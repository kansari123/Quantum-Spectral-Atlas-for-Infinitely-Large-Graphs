"""EXP G noise arms: eps in {3e-4,1e-3}, T=100, Gaussian per-moment
(validated conservative proxy). f<0.51 rungs -> eps/10 (inherited R2
repair). Pruning fixed to noiseless g decision (stated protocol).
Reports registered-primary stitched AND exploratory joint functionals."""
import numpy as np, json, time
from scipy.optimize import nnls
t0=time.time()
d=np.load("stage2a.npz"); lt=np.load("lanczos_truth.npz"); ts=np.load("stage2truth_solves.npz")
au=json.load(open("res_autopsy.json"))
grid=d["grid"]; sigmas=d["sigmas"]; mus=d["mus"]; nb2=d["nb2"]
am=d["alive_mask"]; fmat=d["fmat"]; P=len(d["ports"]); M=d["Z"].shape[1]
n=7624; K=24; T=100
Rtot_true=au["Rtot_true"]; lntau_true=float(ts["lntau_true"])
print("f-flags (<0.51 -> eps/10), rows=rungs:",flush=True)
print(np.round(fmat,3))
ths={}; As={}
for ri,s in enumerate(sigmas):
    y=2.0*s/(s+grid)-1.0; th=np.arccos(np.clip(y,-1,1))
    A=np.cos(np.outer(np.arange(K),th)); A0=A.copy(); A0[0]*=100.0
    As[ri]=A0
inv_g=1.0/grid; log_g=np.log(grid)
def fit_rung(ri,mu_c,nb2_c):
    bb=mu_c[:K].astype(float).copy(); bb[0]*=100.0
    w,_=nnls(As[ri],bb)
    return nb2_c*w
def joint(c,mu_noisy):
    alive=np.where(am[c])[0]
    rows=[100.0*np.ones(len(grid))]; rhs=[100.0]
    for ri in alive:
        rows.append(As[ri][1:]/1.0)  # k>=1 rows unweighted
        rhs.append(mu_noisy[ri,1:K])
    Aall=np.vstack([r if r.ndim==2 else r[None,:] for r in rows])
    ball=np.concatenate([np.atleast_1d(r) for r in rhs])
    try: w,_=nnls(Aall,ball,maxiter=200*Aall.shape[1])
    except RuntimeError:
        from scipy.optimize import lsq_linear
        w=lsq_linear(Aall,ball,bounds=(0,np.inf),method='trf',tol=1e-12,max_iter=400).x
    return nb2[0,c]*w
rng=np.random.default_rng(424242)
out={}
for eps in (3e-4,1e-3):
    reff_err=np.empty((T,P)); rt_err=np.empty(T); lt_err=np.empty(T)
    rts_err=np.empty(T); lts_err=np.empty(T)
    for t in range(T):
        noise=rng.standard_normal(mus.shape)
        eps_eff=np.where(fmat<0.51,eps/10.0,eps)[:, :]
        mu_n=mus.copy(); mu_n[:,1:,:]+= (eps_eff[:,None,:]*noise[:,1:,:])
        # per-port R_eff from smallest alive rung
        for p in range(P):
            sg=np.sort(sigmas[am[p]]); ri=int(np.where(sigmas==sg[0])[0][0])
            Wp=fit_rung(ri,mu_n[ri,:,p],nb2[0,p])
            reff_err[t,p]=abs(float(Wp@inv_g)-ts["Reff_true"][p])/ts["Reff_true"][p]
        # functionals: stitched (primary) + joint (exploratory)
        qi_s=[];ql_s=[];qi_j=[];ql_j=[]
        for c in range(P,P+M):
            sg=np.sort(sigmas[am[c]])
            assign=np.argmin(np.abs(np.log10(grid)[:,None]-np.log10(sg)[None,:]),axis=1)
            Wst=np.zeros(len(grid))
            for di,s in enumerate(sg):
                ri=int(np.where(sigmas==s)[0][0])
                Wr=fit_rung(ri,mu_n[ri,:,c],nb2[0,c])
                Wst[assign==di]=Wr[assign==di]
            qi_s.append(float(Wst@inv_g)); ql_s.append(float(Wst@log_g))
            Wj=joint(c,mu_n[:,:,c])
            qi_j.append(float(Wj@inv_g)); ql_j.append(float(Wj@log_g))
        rts_err[t]=abs(n*np.mean(qi_s)-Rtot_true)/Rtot_true
        lts_err[t]=abs((np.mean(ql_s)-np.log(n))-lntau_true)/n
        rt_err[t]=abs(n*np.mean(qi_j)-Rtot_true)/Rtot_true
        lt_err[t]=abs((np.mean(ql_j)-np.log(n))-lntau_true)/n
        if t%10==0: print("eps=%g trial %d t=%.0fs"%(eps,t,time.time()-t0),flush=True)
    pm=np.median(reff_err,axis=0); p9=np.quantile(reff_err,0.9,axis=0)
    out[str(eps)]=dict(
      reff_trialmed_med=100*float(np.median(pm)),
      reff_trialmed_all=(100*pm).tolist(),
      reff_trialp90_med=100*float(np.median(p9)),
      Rtot_stitched_med=100*float(np.median(rts_err)),
      lntau_stitched_med=float(np.median(lts_err)),
      Rtot_joint_med=100*float(np.median(rt_err)),
      lntau_joint_med=float(np.median(lt_err)))
    print(eps,json.dumps(out[str(eps)],indent=1),flush=True)
json.dump(out,open("res_noise.json","w"),indent=1)
print("done %.0fs"%(time.time()-t0))
