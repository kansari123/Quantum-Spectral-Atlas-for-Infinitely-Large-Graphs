"""EXP G stage 1: control graph P-G1 gates (Foster + forest-ratio)."""
import numpy as np, scipy.sparse as sp, json
from graphatlas import GraphOp, nnls_rung, eval_nearest, flags

A = np.load("control_A.npy")
n = A.shape[0]
deg = A.sum(1)
L = np.diag(deg) - A
Ls = sp.csr_matrix(L)
op = GraphOp(Ls)

# frozen config
alpha = 1.25 * 14.640
sigmas = [1e-1, 1.0, 1e1, 1e2]
K = 24
grid = np.logspace(-3, np.log10(1.2 * alpha), 400)

iu, ju = np.where(np.triu(A, 1) > 0)
edges = list(zip(iu, ju))
m = len(edges)
B = np.zeros((n, m))
for p, (u, v) in enumerate(edges):
    B[u, p] = 1.0; B[v, p] = -1.0

models, mus = {}, {}
for s in sigmas:
    mu, nb2 = op.moments_block(s, K, B)
    mus[s] = mu
    models[s] = nnls_rung(mu, nb2, grid, s, K)
g0, f0 = flags(mus[sigmas[0]])

# g-rule with inherited cut (part of protocol on every run)
alive = []
for s in sigmas:
    g, f = flags(mus[s])
    if np.median(g) >= 5e-3:
        alive.append(s)
if not alive:
    alive = sigmas[:1]

Reff = eval_nearest(models, grid, alive, [0.0])[0]   # (m,)

# truth via dense eig
lam, V = np.linalg.eigh(L)
lam1 = lam[1:]; V1 = V[:, 1:]
Reff_true = np.array([np.sum((V1.T @ B[:, p]) ** 2 / lam1)
                      for p in range(m)])

foster_hat = float(np.sum(Reff))
foster_err = abs(foster_hat - (n - 1)) / (n - 1)

# forest-ratio on 10 frozen edges (seed 2026): R_uv = tau(G/uv)/tau(G)
rng = np.random.default_rng(2026)
pick = rng.choice(m, size=10, replace=False)


def logtau(Lm):
    s2, ld = np.linalg.slogdet(Lm[1:, 1:])
    assert s2 > 0
    return ld


lt_G = logtau(L)
ratio_err = []
for p in pick:
    u, v = edges[p]
    # contract u,v: merge v into u
    keep = [i for i in range(n) if i != v]
    Ac = A.copy()
    Ac[u] += Ac[v]; Ac[:, u] += Ac[:, v]
    Ac[u, u] = 0.0
    Ac = Ac[np.ix_(keep, keep)]
    Lc = np.diag(Ac.sum(1)) - Ac
    r_det = np.exp(logtau(Lc) - lt_G)
    ratio_err.append(abs(Reff[p] - r_det) / r_det)

res = dict(
    foster_hat=foster_hat, foster_err_pct=100 * foster_err,
    forest_ratio_err_pct=[100 * e for e in ratio_err],
    forest_ratio_max_pct=100 * max(ratio_err),
    pipeline_vs_truth_med_pct=100 * float(np.median(
        np.abs(Reff - Reff_true) / Reff_true)),
    pipeline_vs_truth_max_pct=100 * float(np.max(
        np.abs(Reff - Reff_true) / Reff_true)),
    alive=[float(s) for s in alive], drift=op.drift,
    g_med_per_rung={str(s): float(np.median(flags(mus[s])[0]))
                    for s in sigmas},
)
print(json.dumps(res, indent=1))
json.dump(res, open("res_control.json", "w"), indent=1)
