"""EXP G pipeline: Q-PVL moment engine on graph Laplacians.
Inherited pieces mirror qpvl/realchip/qpvl_core.py verbatim in structure:
rung warp Y = 2s(L+s)^{-1}-1 via one sparse LU per shift, K Chebyshev
moments by three-term recursion, NNLS on a log pole grid with k=0 row
x100, nearest-rung evaluation. Registered deltas: C=I (S=L, R_inf=0),
exact kernel deflation, real-s evaluation + s->0 endpoint, decade-
stitched composite measure for global functionals, log kernel."""
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spla
from scipy.optimize import nnls


class GraphOp:
    def __init__(self, L):
        self.L = L.tocsr()
        self.n = L.shape[0]
        self.one = np.ones(self.n) / np.sqrt(self.n)
        self.drift = 0.0          # P-G8 gate accumulator

    def _deflate(self, V):
        c = self.one @ V
        self.drift = max(self.drift, float(np.max(np.abs(c))))
        return V - np.outer(self.one, c)

    def shift_lu(self, sigma):
        return spla.splu((self.L + sigma * sp.identity(self.n)).tocsc())

    def Y_apply(self, lu, sigma, V):
        # Y = 2 sigma (L + sigma)^{-1} - I, then exact kernel deflation
        return self._deflate(2.0 * sigma * lu.solve(V) - V)

    def moments_block(self, sigma, K, B):
        """B: (n,P) raw port/probe vectors. Returns mu (K,P) for the
        NORMALIZED columns, plus nb2 (P,) = ||P_perp b||^2."""
        lu = self.shift_lu(sigma)
        Bp = B - np.outer(self.one, self.one @ B)
        nb2 = np.sum(Bp * Bp, axis=0)
        V = Bp / np.sqrt(nb2)
        mu = np.empty((K, len(nb2)))
        mu[0] = 1.0
        tp = V
        tc = self.Y_apply(lu, sigma, V)
        mu[1] = np.sum(V * tc, axis=0)
        for k in range(2, K):
            tn = 2.0 * self.Y_apply(lu, sigma, tc) - tp
            mu[k] = np.sum(V * tn, axis=0)
            tp, tc = tc, tn
        return mu, nb2


def flags(mu):
    """Two-flag protocol from the first moments (per port): g emptiness,
    f fragility. g = <((y+1)/2)^2> = <(s/(s+lam))^2>, f = <s/(s+lam)>."""
    g = ((1.0 + mu[2]) / 2.0 + 2.0 * mu[1] + 1.0) / 4.0
    f = (1.0 + mu[1]) / 2.0
    return g, f


def nnls_rung(mu_kP, nb2, grid, sigma, K):
    """Per-rung NNLS models for a block of ports. Mirrors nnls_models:
    A[k,j] = cos(k * arccos(y_j)), row 0 x100. Returns weights (P, Ngrid)
    already scaled by nb2 (so model Z(s) = sum W/(lam+s) is in b-units)."""
    y = 2.0 * sigma / (sigma + grid) - 1.0
    th = np.arccos(np.clip(y, -1.0, 1.0))
    A = np.cos(np.outer(np.arange(K), th))
    A0 = A.copy(); A0[0] *= 100.0
    P = mu_kP.shape[1]
    Wout = np.empty((P, len(grid)))
    for p in range(P):
        bb = mu_kP[:K, p].astype(float).copy(); bb[0] *= 100.0
        w, _ = nnls(A0, bb)
        Wout[p] = nb2[p] * w
    return Wout


def eval_nearest(models, grid, sigmas_alive, s_vals):
    """models: dict sigma -> (P,Ngrid) weights. Nearest surviving rung in
    log-s; s=0 handled by smallest surviving rung."""
    sg = np.array(sorted(sigmas_alive))
    out = np.empty((len(s_vals), models[sg[0]].shape[0]))
    for i, s in enumerate(s_vals):
        if s <= 0:
            d = sg[0]
        else:
            d = sg[int(np.argmin(np.abs(np.log10(sg) - np.log10(s))))]
        W = models[d]
        out[i] = W @ (1.0 / (grid + s))
    return out


def stitch(models, grid, sigmas_alive):
    """Decade-stitched composite measure: each grid pole assigned to its
    nearest surviving rung in log-lambda; take that rung's weights on its
    own band. Returns (P,Ngrid) stitched weights."""
    sg = np.array(sorted(sigmas_alive))
    assign = np.argmin(np.abs(np.log10(grid)[:, None] -
                              np.log10(sg)[None, :]), axis=1)
    P = models[sg[0]].shape[0]
    Wst = np.zeros((P, len(grid)))
    for di, d in enumerate(sg):
        band = assign == di
        Wst[:, band] = models[d][:, band]
    return Wst


def functional(Wst, grid, fvals):
    return Wst @ fvals


def make_noisy(mu, eps, rng):
    out = mu.copy()
    out[1:] += eps * rng.standard_normal(out[1:].shape)
    return out
