import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spla, json, time
from graphatlas import GraphOp, nnls_rung, flags
t0=time.time()
Ws=sp.load_npz("sbm_W.npz"); n=Ws.shape[0]
deg=np.asarray(Ws.sum(1)).ravel(); L=sp.diags(deg)-Ws
op=GraphOp(L)
alpha=33.361; K=24; G_CUT=5e-3
sigmas=[1e-6,1e-5,1e-4,1e-3,1e-2,1e-1,1.0,1e1,1e2]
grid=np.logspace(-7,np.log10(1.2*alpha),400)
rng=np.random.default_rng(2026); csz=512
ports=[(0*csz+int(rng.integers(csz)), 7*csz+int(rng.integers(csz))),
       (0*csz+int(rng.integers(csz)), 1*csz+int(rng.integers(csz))),
       (3*csz+int(rng.integers(csz)), 3*csz+int(rng.integers(csz)))]
hub=int(np.argmax(deg)); v=int(rng.integers(n))
ports.append((hub,v)); P=len(ports)
names=["far-inter(c0,c7)","adj-inter(c0,c1)","intra(c3)","hub+rand"]
B=np.zeros((n,P))
for p,(u,v) in enumerate(ports): B[u,p]=1.; B[v,p]=-1.
mus,models={},{}
for s in sigmas:
    mu,nb2=op.moments_block(s,K,B); mus[s]=mu
    models[s]=nnls_rung(mu,nb2,grid,s,K)
print("moments+fits %.0fs drift=%.1e"%(time.time()-t0,op.drift),flush=True)
gmat=np.array([flags(mus[s])[0] for s in sigmas])
print("g per rung (rows 1e-6..1e2) x port:"); print(np.format_float_scientific if False else np.round(np.log10(np.maximum(gmat,1e-12)),2))
alive_pruned=[[sigmas[d] for d in range(len(sigmas)) if gmat[d,p]>=G_CUT] or [sigmas[-1]] for p in range(P)]
# truth
one=np.ones(n)/np.sqrt(n); Bp=B-np.outer(one,one@B)
lu=spla.splu((L+1e-13*sp.identity(n)).tocsc())
X=lu.solve(Bp); Reff_true=np.sum(Bp*X,axis=0)
inv_g=1.0/grid
def reff_from(sig_list,p):
    ri=int(np.where(np.array(sigmas)==sorted(sig_list)[0])[0][0])
    return float(models[sigmas[ri]][p]@inv_g)
res={"ports":ports,"names":names,"Reff_true":Reff_true.tolist(),
     "alive":{names[p]:[float(s) for s in alive_pruned[p]] for p in range(P)},
     "g_by_rung":{names[p]:[float(gmat[d,p]) for d in range(len(sigmas))] for p in range(P)}}
full=list(sigmas)
err_full=[abs(reff_from(full,p)-Reff_true[p])/Reff_true[p] for p in range(P)]
err_prun=[abs(reff_from(alive_pruned[p],p)-Reff_true[p])/Reff_true[p] for p in range(P)]
res["err_full_pct"]=[100*e for e in err_full]; res["err_pruned_pct"]=[100*e for e in err_prun]
res["ratio"]=[ (err_prun[p]/err_full[p]) if err_full[p]>0 else np.inf for p in range(P)]
D=[int(np.ceil(4*np.sqrt(alpha/s))) for s in sigmas]
res["D_per_rung"]=D; res["SumD_full"]=int(np.sum(D))
res["SumD_pruned"]={names[p]:int(np.sum([D[sigmas.index(s)] for s in alive_pruned[p]])) for p in range(P)}
# truth small-mode mass per port for the autopsy (smallest 8 nonzero eigs)
lam_s,V_s=spla.eigsh(L.tocsc()+1e-13*sp.identity(n),k=9,sigma=0,which='LM')
idx=np.argsort(lam_s); lam_s=lam_s[idx]; V_s=V_s[:,idx]
small_mass=[float(np.sum((V_s[:,1:9].T@Bp[:,p])**2)/np.sum(Bp[:,p]**2)) for p in range(P)]
res["lam_small"]=lam_s[1:9].tolist(); res["small_mode_mass"]=small_mass
print(json.dumps({k:v for k,v in res.items() if k not in("g_by_rung",)},indent=1))
json.dump(res,open("res_sbm.json","w"),indent=1)
