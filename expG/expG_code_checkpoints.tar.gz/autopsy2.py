import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spla, json, time
from scipy.optimize import nnls, lsq_linear
t0=time.time()
d=np.load("stage2a.npz"); lt=np.load("lanczos_truth.npz")
grid=d["grid"]; sigmas=d["sigmas"]; models=d["models"]; am=d["alive_mask"]
mus=d["mus"]; nb2=d["nb2"]; P=len(d["ports"]); M=d["Z"].shape[1]; n=7624; K=24
# ---- eig-free R_tot truth FIRST ----
W=sp.load_npz("lastfm_W.npz"); deg=np.asarray(W.sum(1)).ravel()
L=(sp.diags(deg)-W).tocsc(); one=np.ones(n)/np.sqrt(n)
lu=spla.splu((L+1e-9*sp.identity(n)).tocsc())
trLp=0.0
for a in range(0,n,400):
    b=min(a+400,n); E=np.zeros((n,b-a))
    E[np.arange(a,b),np.arange(b-a)]=1.0
    E-=np.outer(one,one@E)
    trLp+=float(np.sum(E*lu.solve(E)))
Rtot_true=n*trLp
r2=json.load(open("res_stage2c.json"))
print("Rtot_true=%.6e hat=%.6e err=%.3f%% (t=%.0fs)"%(Rtot_true,r2["Rtot_hat"],
      100*abs(r2["Rtot_hat"]-Rtot_true)/Rtot_true,time.time()-t0),flush=True)
# ---- X-G1 joint fit with adequate iterations ----
def joint_fit(c):
    alive=np.where(am[c])[0]
    rows=[100.0*np.ones(len(grid))]; rhs=[100.0]
    for ri in alive:
        s=sigmas[ri]
        y=2.0*s/(s+grid)-1.0; th=np.arccos(np.clip(y,-1,1))
        rows.append(np.cos(np.outer(np.arange(1,K),th)))
        rhs.append(mus[ri,1:K,c])
    Aall=np.vstack([r if r.ndim==2 else r[None,:] for r in rows])
    ball=np.concatenate([np.atleast_1d(r) for r in rhs])
    try:
        w,_=nnls(Aall,ball,maxiter=200*Aall.shape[1])
    except RuntimeError:
        w=lsq_linear(Aall,ball,bounds=(0,np.inf),method='trf',
                     tol=1e-12,max_iter=400).x
    return nb2[0,c]*w
def stitch_col(c):
    sg=np.sort(sigmas[am[c]])
    assign=np.argmin(np.abs(np.log10(grid)[:,None]-np.log10(sg)[None,:]),axis=1)
    Wst=np.zeros(len(grid))
    for di,s in enumerate(sg):
        ri=int(np.where(sigmas==s)[0][0]); Wst[assign==di]=models[ri,c][assign==di]
    return Wst
qi_j=[];ql_j=[];qi_s=[];ql_s=[]
for c in range(P,P+M):
    Wj=joint_fit(c); Ws=stitch_col(c)
    qi_j.append(float(Wj@(1.0/grid))); ql_j.append(float(Wj@np.log(grid)))
    qi_s.append(float(Ws@(1.0/grid))); ql_s.append(float(Ws@np.log(grid)))
    print("probe %d t=%.0fs"%(c-P,time.time()-t0),flush=True)
qi_j,ql_j,qi_s,ql_s=map(np.array,(qi_j,ql_j,qi_s,ql_s))
qie_j=np.abs(qi_j-lt["q_inv_true"])/lt["q_inv_true"]; g5a_j=np.abs(ql_j-lt["q_log_true"])/n
qie_s=np.abs(qi_s-lt["q_inv_true"])/lt["q_inv_true"]; g5a_s=np.abs(ql_s-lt["q_log_true"])/n
win=int(np.sum((qie_j<qie_s)&(g5a_j<g5a_s)))
Rtj=n*float(np.mean(qi_j)); ltj=float(np.mean(ql_j))-np.log(n)
lnt=9479.003040964237
out=dict(Rtot_true=Rtot_true,Rtot_err_stitched_pct=100*abs(r2["Rtot_hat"]-Rtot_true)/Rtot_true,
 joint_qinv_err_pct=(100*qie_j).tolist(),joint_qinv_med=100*float(np.median(qie_j)),
 joint_g5a=g5a_j.tolist(),joint_g5a_med=float(np.median(g5a_j)),
 stitched_qinv_med=100*float(np.median(qie_s)),stitched_g5a_med=float(np.median(g5a_s)),
 xg1_wins=win,Rtot_joint=Rtj,Rtot_joint_err_pct=100*abs(Rtj-Rtot_true)/Rtot_true,
 lntau_joint=ltj,lntau_joint_err_nats_node=abs(ltj-lnt)/n)
print(json.dumps(out,indent=1))
json.dump(out,open("res_autopsy.json","w"),indent=1)
