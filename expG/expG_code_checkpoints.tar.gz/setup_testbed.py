"""Setup measurements for EXP G (graph transfer). Declared pre-registration
testbed characterization ONLY: no pipeline outputs computed here.
Mirrors the P1 pattern: spectrum bounds are part of the frozen testbed."""
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spla, json

rng = np.random.default_rng(7)

# ---------- primary: LastFM Asia ----------
E = np.loadtxt("lastfm_edges.csv", delimiter=",", skiprows=1, dtype=int)
n = int(E.max()) + 1
# undirected simple graph, weight 1
rows = np.concatenate([E[:, 0], E[:, 1]])
cols = np.concatenate([E[:, 1], E[:, 0]])
W = sp.csr_matrix((np.ones(len(rows)), (rows, cols)), shape=(n, n))
W.data[:] = 1.0  # dedupe multi-entries
W = ((W + W.T) > 0).astype(float)
W.setdiag(0); W.eliminate_zeros()
deg = np.asarray(W.sum(1)).ravel()
L = sp.diags(deg) - W
m = int(W.nnz // 2)

# connectivity
ncomp, lab = sp.csgraph.connected_components(W, directed=False)

# alpha: power iteration on L (1.25 safety like qpvl_core.alpha)
v = rng.standard_normal(n); v /= np.linalg.norm(v)
for _ in range(60):
    w = L @ v; lam_pow = float(v @ w); v = w / np.linalg.norm(w)
alpha = 1.25 * lam_pow

# lambda_2 estimate: inverse iteration on (L + s0)^{-1} with explicit
# deflation of the all-ones kernel
s0 = 1e-6
lu = spla.splu((L + s0 * sp.identity(n)).tocsc())
one = np.ones(n) / np.sqrt(n)
v = rng.standard_normal(n); v -= (one @ v) * one; v /= np.linalg.norm(v)
for _ in range(200):
    w = lu.solve(v); w -= (one @ w) * one; v = w / np.linalg.norm(w)
lam2_est = float(v @ (L @ v))

stats = dict(name="lastfm_asia", n=n, m=m, ncomp=int(ncomp),
             d_min=float(deg.min()), d_max=float(deg.max()),
             d_mean=float(deg.mean()),
             lam_pow=lam_pow, alpha=alpha, lam2_est=lam2_est)
print(json.dumps(stats, indent=1))

# ---------- control: n=60 connected ER, exact combinatorics ----------
nc = 60
while True:
    Ac = (rng.random((nc, nc)) < 0.12).astype(float)
    Ac = np.triu(Ac, 1); Ac = Ac + Ac.T
    dc = Ac.sum(1)
    Lc = np.diag(dc) - Ac
    if sp.csgraph.connected_components(sp.csr_matrix(Ac))[0] == 1:
        break
np.save("control_A.npy", Ac)
ev = np.linalg.eigvalsh(Lc)
print("control: n=60, m=%d, lam2=%.4f, lam_max=%.3f" %
      (int(Ac.sum() // 2), ev[1], ev[-1]))

# ---------- pruning demo: designed SBM with empty decades ----------
# 8 communities x 512, intra ER p=0.02 w=1; inter: 3 bridge edges per
# adjacent pair, weight 1e-3  -> 7 small eigenvalues ~O(1e-3 scale),
# bulk ~[1,20]; decades 1e-2 and 1e-1 designed EMPTY.
ns, k, csz = 4096, 8, 512
ru, cu, wu = [], [], []
for c in range(k):
    base = c * csz
    blk = (rng.random((csz, csz)) < 0.02)
    iu, ju = np.where(np.triu(blk, 1))
    ru += list(base + iu); cu += list(base + ju); wu += [1.0] * len(iu)
for c in range(k - 1):
    for _ in range(3):
        i = c * csz + rng.integers(csz); j = (c + 1) * csz + rng.integers(csz)
        ru.append(i); cu.append(j); wu.append(1e-3)
Ws = sp.csr_matrix((wu + wu, (ru + cu, cu + ru)), shape=(ns, ns))
degs = np.asarray(Ws.sum(1)).ravel()
Ls = sp.diags(degs) - Ws
print("sbm: n=%d nnz=%d comps=%d" %
      (ns, Ws.nnz, sp.csgraph.connected_components(Ws, directed=False)[0]))
sp.save_npz("sbm_W.npz", Ws)

# sbm alpha + lam2 est (same procedures)
v = rng.standard_normal(ns); v /= np.linalg.norm(v)
for _ in range(60):
    w = Ls @ v; lp = float(v @ w); v = w / np.linalg.norm(w)
lus = spla.splu((Ls + 1e-8 * sp.identity(ns)).tocsc())
ones = np.ones(ns) / np.sqrt(ns)
v = rng.standard_normal(ns); v -= (ones @ v) * ones; v /= np.linalg.norm(v)
for _ in range(200):
    w = lus.solve(v); w -= (ones @ w) * ones; v = w / np.linalg.norm(w)
print("sbm: alpha=%.3f lam2_est=%.3e" % (1.25 * lp, float(v @ (Ls @ v))))

sp.save_npz("lastfm_W.npz", W)
json.dump(stats, open("testbed_stats.json", "w"), indent=1)
