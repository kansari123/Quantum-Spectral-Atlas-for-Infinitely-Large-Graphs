import numpy as np, json, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
d=np.load("stage2a.npz"); ts=np.load("stage2truth_solves.npz")
r2=json.load(open("res_stage2c.json")); au=json.load(open("res_autopsy.json"))
rn=json.load(open("res_noise.json")); rs=json.load(open("res_sbm.json"))
grid=d["grid"]; sigmas=d["sigmas"]; models=d["models"]; am=d["alive_mask"]
svals=ts["svals"]; P=12
def eval_col(c,s):
    sg=sigmas[am[c]]
    if s<=0:
        di=int(np.where(sigmas==np.sort(sg)[0])[0][0])
    else:
        dd=int(np.argmin(np.abs(np.log10(sg)-np.log10(s))))
        di=int(np.where(sigmas==sg[dd])[0][0])
    return float(models[di,c]@(1.0/(grid+s)))
# Fig 1: R(s) sweep + endpoint
sel=[1,6,9,11]; lbl=["random pair","top-hub pair","far pair A","far pair C"]
fig,ax=plt.subplots(figsize=(7,4.6))
cols=plt.rcParams['axes.prop_cycle'].by_key()['color']
for i,(p,l) in enumerate(zip(sel,lbl)):
    ax.plot(svals,ts["Rs_true"][p],'-',color=cols[i],lw=1.6,label=l+" (truth)")
    Rhat=[eval_col(p,s) for s in svals]
    ax.plot(svals,Rhat,'o',color=cols[i],ms=4,mfc='none')
    ax.plot([svals[0]*0.25],[eval_col(p,0.0)],'*',color=cols[i],ms=12)
    ax.plot([svals[0]*0.25],[ts["Reff_true"][p]],'+',color='k',ms=10,mew=1.4)
ax.set_xscale('log'); ax.set_yscale('log')
ax.set_xlabel(r'regularization $s$'); ax.set_ylabel(r'$R(s)=b^T(L+s)^{-1}b$')
ax.set_title('LastFM Asia: regularized resistance sweep and $s\\to 0$ endpoint\n(lines=truth, circles=nearest-rung eval, stars=extrapolated $R_{eff}$, +=exact)')
ax.legend(fontsize=8,loc='lower left'); fig.tight_layout(); fig.savefig("figs/fig1_Rs_sweep.png",dpi=140)
# Fig 2: stitched vs joint quad legs
fig,axs=plt.subplots(1,2,figsize=(8.6,4.0))
x=np.arange(8); w=0.38
st_qi=np.array(r2["quad_inv_all"]); jt_qi=np.array(au["joint_qinv_err_pct"])
st_g5=np.array(r2["g5a_all"]); jt_g5=np.array(au["joint_g5a"])
axs[0].bar(x-w/2,st_qi,w,label='stitched (registered)'); axs[0].bar(x+w/2,np.maximum(jt_qi,1e-11),w,label='joint (X-G1)')
axs[0].set_yscale('log'); axs[0].set_ylabel(r'$\langle z|L^{+}|z\rangle$ error [%]'); axs[0].axhline(2,ls='--',c='k',lw=0.8)
axs[0].set_xlabel('Hutchinson probe'); axs[0].legend(fontsize=8); axs[0].set_title('inverse kernel leg (bar 2%)')
axs[1].bar(x-w/2,st_g5,w); axs[1].bar(x+w/2,np.maximum(jt_g5,1e-14),w)
axs[1].set_yscale('log'); axs[1].set_ylabel(r'$\langle z|\ln L|z\rangle$ error [nats/node]'); axs[1].axhline(0.02,ls='--',c='k',lw=0.8)
axs[1].set_xlabel('Hutchinson probe'); axs[1].set_title('log kernel leg (bar 0.02) — P-G5a')
fig.suptitle('M-D seam overcount: stitched fails log bar; joint fit hits machine precision (signed defect +0.5..3.5%)',fontsize=9)
fig.tight_layout(rect=[0,0,1,0.94]); fig.savefig("figs/fig2_stitch_vs_joint.png",dpi=140)
# Fig 3: SBM pruning
fig,axs=plt.subplots(1,2,figsize=(8.8,4.0))
sig9=np.array([1e-6,1e-5,1e-4,1e-3,1e-2,1e-1,1,10,100])
for i,nm in enumerate(rs["names"]):
    axs[0].plot(sig9,np.maximum(rs["g_by_rung"][nm],1e-12),'o-',ms=4,label=nm)
axs[0].axhline(5e-3,c='r',ls='--',lw=1,label='G_CUT=5e-3')
axs[0].axvspan(1e-4,1e-1,color='0.9',zorder=0)
axs[0].set_xscale('log'); axs[0].set_yscale('log')
axs[0].set_xlabel(r'rung $\sigma$'); axs[0].set_ylabel('g flag (emptiness)')
axs[0].set_title('g vs rung; shaded = designed-empty decades\ninter-port small-mode mass 1.95e-3 < cut')
axs[0].legend(fontsize=7)
x=np.arange(4)
axs[1].bar(x-0.2,rs["err_full_pct"],0.4,label='full ladder')
axs[1].bar(x+0.2,np.maximum(rs["err_pruned_pct"],1e-8),0.4,label='g-pruned')
axs[1].set_yscale('log'); axs[1].set_xticks(x); axs[1].set_xticklabels(rs["names"],rotation=12,fontsize=7)
axs[1].set_ylabel(r'$R_{eff}$ error [%]'); axs[1].legend(fontsize=8)
axs[1].set_title('P-G6 FAIL: pruning removes low-mass/high-leverage modes')
fig.tight_layout(); fig.savefig("figs/fig3_sbm_pruning.png",dpi=140)
# Fig 4: noise arms
fig,axs=plt.subplots(1,2,figsize=(8.8,4.0))
xp=np.arange(P)
a3=np.array(rn["0.0003"]["reff_trialmed_all"]); a1=np.array(rn["0.001"]["reff_trialmed_all"])
axs[0].bar(xp-0.2,a3,0.4,label=r'$\epsilon=3\times10^{-4}$')
axs[0].bar(xp+0.2,a1,0.4,label=r'$\epsilon=10^{-3}$')
axs[0].axhline(5,ls='--',c='k',lw=0.8); axs[0].axhline(10,ls=':',c='k',lw=0.8)
axs[0].set_yscale('log'); axs[0].set_xlabel('port'); axs[0].set_ylabel('trial-median error [%]')
axs[0].set_title('P-G3: noisy $R_{eff}$ per port (T=100)'); axs[0].legend(fontsize=8)
cats=['$R_{tot}$ [%]\n stitched','$R_{tot}$ [%]\n joint',r'$\ln\tau$ [nats/nd]'+'\n stitched',r'$\ln\tau$ [nats/nd]'+'\n joint']
v3=[rn["0.0003"]["Rtot_stitched_med"],rn["0.0003"]["Rtot_joint_med"],rn["0.0003"]["lntau_stitched_med"],rn["0.0003"]["lntau_joint_med"]]
v1=[rn["0.001"]["Rtot_stitched_med"],rn["0.001"]["Rtot_joint_med"],rn["0.001"]["lntau_stitched_med"],rn["0.001"]["lntau_joint_med"]]
xc=np.arange(4)
axs[1].bar(xc-0.2,v3,0.4); axs[1].bar(xc+0.2,v1,0.4)
axs[1].set_yscale('log'); axs[1].set_xticks(xc); axs[1].set_xticklabels(cats,fontsize=7)
axs[1].set_title(r'global functionals under noise (median of T=100)')
fig.tight_layout(); fig.savefig("figs/fig4_noise.png",dpi=140)
print("figs done")
