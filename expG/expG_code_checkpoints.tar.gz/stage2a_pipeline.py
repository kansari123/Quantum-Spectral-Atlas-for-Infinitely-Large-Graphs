import numpy as np, scipy.sparse as sp, json, time
from graphatlas import GraphOp, nnls_rung, flags
t0=time.time()
W = sp.load_npz("lastfm_W.npz"); n=W.shape[0]
deg = np.asarray(W.sum(1)).ravel()
L = sp.diags(deg)-W
op = GraphOp(L)
alpha = 271.315597332793
sigmas = [1e-2,1e-1,1.0,1e1,1e2,1e3]; K=24; G_CUT=5e-3
grid = np.logspace(-3, np.log10(1.2*alpha), 400)
rng = np.random.default_rng(2026)
ports=[]
for _ in range(6):
    u,v = rng.choice(n,size=2,replace=False); ports.append((int(u),int(v)))
hubs = np.argsort(deg)[-3:][::-1]
for h in hubs:
    v=int(rng.integers(n))
    while v==h: v=int(rng.integers(n))
    ports.append((int(h),v))
start=int(rng.integers(n))
d1=sp.csgraph.dijkstra(W,indices=start,unweighted=True)
ecc=int(np.argmax(d1))
d2=sp.csgraph.dijkstra(W,indices=ecc,unweighted=True)
far3=np.argsort(d2)[-3:][::-1]
for f in far3: ports.append((ecc,int(f)))
P=len(ports)
Zp = np.random.default_rng(31337).choice([-1.,1.],size=(n,8)); M=8
B=np.zeros((n,P+M))
for p,(u,v) in enumerate(ports): B[u,p]=1.; B[v,p]=-1.
B[:,P:]=Zp
mus,nb2s,models={},{},{}
for s in sigmas:
    mu,nb2=op.moments_block(s,K,B); mus[s],nb2s[s]=mu,nb2
    models[s]=nnls_rung(mu,nb2,grid,s,K)
    print("rung %g t=%.1fs"%(s,time.time()-t0),flush=True)
gmat=np.array([flags(mus[s])[0] for s in sigmas])
fmat=np.array([flags(mus[s])[1] for s in sigmas])
alive=[[sigmas[d] for d in range(len(sigmas)) if gmat[d,c]>=G_CUT] or list(sigmas) for c in range(P+M)]
np.savez("stage2a.npz", mus=np.array([mus[s] for s in sigmas]),
         nb2=np.array([nb2s[s] for s in sigmas]),
         models=np.array([models[s] for s in sigmas]),
         gmat=gmat,fmat=fmat,grid=grid,sigmas=np.array(sigmas),
         ports=np.array(ports),Z=Zp,
         alive_mask=np.array([[s in alive[c] for s in sigmas] for c in range(P+M)]),
         drift=op.drift)
print("alive per column:",{c:alive[c] for c in range(P+M)})
print("drift %.2e  done %.1fs"%(op.drift,time.time()-t0))
