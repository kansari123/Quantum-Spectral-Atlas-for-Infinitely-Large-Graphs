import numpy as np, json
d=np.load("stage2a.npz"); ts=np.load("stage2truth_solves.npz"); lt=np.load("lanczos_truth.npz")
grid=d["grid"]; sigmas=d["sigmas"]; models=d["models"]  # (nrung,P+M,Ngrid)
alive_mask=d["alive_mask"]; ports=d["ports"]; P=len(ports); M=d["Z"].shape[1]
n=7624
def eval_col(c,s):
    sg=sigmas[alive_mask[c]]
    dd=int(np.argmin(np.abs(np.log10(sg)-np.log10(s)))) if s>0 else 0
    di=int(np.where(sigmas==sorted(sg)[0])[0][0]) if s<=0 else int(np.where(sigmas==sg[dd])[0][0])
    return float(models[di,c]@(1.0/(grid+s)))
def stitch_col(c):
    sg=np.sort(sigmas[alive_mask[c]])
    assign=np.argmin(np.abs(np.log10(grid)[:,None]-np.log10(sg)[None,:]),axis=1)
    Wst=np.zeros(len(grid))
    for di,s in enumerate(sg):
        ri=int(np.where(sigmas==s)[0][0])
        Wst[assign==di]=models[ri,c][assign==di]
    return Wst
svals=ts["svals"]
Rs_hat=np.array([[eval_col(p,s) for s in svals] for p in range(P)])
Reff_hat=np.array([eval_col(p,0.0) for p in range(P)])
band=np.max(np.abs(Rs_hat-ts["Rs_true"])/np.abs(ts["Rs_true"]),axis=1)
reff=np.abs(Reff_hat-ts["Reff_true"])/ts["Reff_true"]
Wst=np.array([stitch_col(c) for c in range(P+M)])
nb2_all=d["nb2"][0]
mass=np.abs(Wst.sum(1)-nb2_all)/nb2_all
qi=Wst[P:]@(1.0/grid); ql=Wst[P:]@np.log(grid)
qie=np.abs(qi-lt["q_inv_true"])/lt["q_inv_true"]
g5a=np.abs(ql-lt["q_log_true"])/n
Rtot_hat=n*float(np.mean(qi))
sumlog_hat=float(np.mean(ql)); lntau_hat=sumlog_hat-np.log(n)
lntau_true=float(ts["lntau_true"])
res=dict(band_med=100*float(np.median(band)),band_all=(100*band).tolist(),
 reff_med=100*float(np.median(reff)),reff_p90=100*float(np.quantile(reff,0.9)),
 reff_all=(100*reff).tolist(),reff_hat=Reff_hat.tolist(),reff_true=ts["Reff_true"].tolist(),
 mass_med=100*float(np.median(mass)),mass_max=100*float(np.max(mass)),
 quad_inv_med=100*float(np.median(qie)),quad_inv_all=(100*qie).tolist(),
 g5a_med=float(np.median(g5a)),g5a_all=g5a.tolist(),
 lntau_hat=lntau_hat,lntau_true=lntau_true,
 g5b_nats_per_node=abs(lntau_hat-lntau_true)/n,
 Rtot_hat=Rtot_hat,
 hutch_probe_mean_qinv=float(np.mean(lt["q_inv_true"])),
 hutch_probe_sd_qinv=float(np.std(lt["q_inv_true"])))
print(json.dumps(res,indent=1))
json.dump(res,open("res_stage2c.json","w"),indent=1)
