import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spla, time
t0=time.time()
W = sp.load_npz("lastfm_W.npz"); n=W.shape[0]
deg=np.asarray(W.sum(1)).ravel(); L=(sp.diags(deg)-W).tocsc()
d=np.load("stage2a.npz")
B=np.zeros((n,d["ports"].shape[0]+d["Z"].shape[1]))
for p,(u,v) in enumerate(d["ports"]): B[u,p]=1.; B[v,p]=-1.
B[:,d["ports"].shape[0]:]=d["Z"]
one=np.ones(n)/np.sqrt(n); Bp=B-np.outer(one,one@B)
alpha=271.315597332793
svals=np.logspace(-2,np.log10(alpha),25)
P=d["ports"].shape[0]
Rs=np.empty((P,len(svals)))
for i,s in enumerate(svals):
    lu=spla.splu((L+s*sp.identity(n)).tocsc())
    X=lu.solve(Bp[:,:P]); Rs[:,i]=np.sum(Bp[:,:P]*X,axis=0)
print("sweep %.1fs"%(time.time()-t0),flush=True)
lu0=spla.splu((L+1e-9*sp.identity(n)).tocsc())
X0=lu0.solve(Bp); q0=np.sum(Bp*X0,axis=0)  # <b|(L+1e-9)^-1|b>; rel err ~1e-8/lam2
# ln tau truth via reduced-Laplacian sparse logdet (matrix-tree)
Lr=(sp.diags(deg)-W).tolil()[1:,1:].tocsc()
lur=spla.splu(Lr)
lntau=float(np.sum(np.log(np.abs(lur.U.diagonal()))))
np.savez("stage2truth_solves.npz",svals=svals,Rs_true=Rs,
         Reff_true=q0[:P],q_inv_true=q0[P:],lntau_true=lntau)
print("Reff_true:",np.round(q0[:P],4))
print("lntau=%.6f (%.4f nats/node) t=%.1fs"%(lntau,lntau/n,time.time()-t0))
